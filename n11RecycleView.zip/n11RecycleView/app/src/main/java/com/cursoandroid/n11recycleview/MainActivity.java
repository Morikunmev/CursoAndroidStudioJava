package com.cursoandroid.n11recycleview;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    String []nombres= {"anana", "banana", "cereza", "kiwi", "limon", "manzana","naranja","sandia"};
    float []precios= {170, 180, 180, 180, 110, 120, 10, 280};

    int []fotos= {R.drawable.anana, R.drawable.banana, R.drawable.cereza, R.drawable.kiwi, R.drawable.limon, R.drawable.manzana,R.drawable.naranja,R.drawable.sandia};

    RecyclerView rv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rv1=findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv1.setLayoutManager(linearLayoutManager);
        rv1.setAdapter(new AdaptadorFrutas());
    }

    private class AdaptadorFrutas extends RecyclerView.Adapter<AdaptadorFrutas.AdaptadorFrutasHolder> {
        @NonNull
        @Override
        public AdaptadorFrutasHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorFrutasHolder(getLayoutInflater().inflate(R.layout.itemfruta,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorFrutasHolder holder, int position) {
            Log.d("Adapter", "Posición: " + position + ", Nombre: " + nombres[position] + ", Precio: " + precios[position]);
            holder.imprimir(position);
        }


        @Override
        public int getItemCount() {
            return nombres.length;
        }

        private class AdaptadorFrutasHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            TextView tv1, tv2;
            ImageView iv1;
            public AdaptadorFrutasHolder(@NonNull View itemView) {
                super(itemView);
                iv1 = itemView.findViewById(R.id.imageView);
                tv1 = itemView.findViewById(R.id.tvnombre);
                tv2 = itemView.findViewById(R.id.tvprecio);
                itemView.setOnClickListener(this);
            }

            public void imprimir(int position) {
                iv1.setImageResource(fotos[position]);
                tv1.setText(nombres[position]);
                tv2.setText(String.valueOf(precios[position]));
            }

            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,nombres[getLayoutPosition()], Toast.LENGTH_SHORT).show();
            }
        }
    }
}