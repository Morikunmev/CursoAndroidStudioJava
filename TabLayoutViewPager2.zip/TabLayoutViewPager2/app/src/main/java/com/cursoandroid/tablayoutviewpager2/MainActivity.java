package com.cursoandroid.tablayoutviewpager2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TableLayout;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {
    String[] dias = {"lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"};
    String[] actividades = {"", "", "", "", "", "", ""}; // Almacena las actividades

    ViewPager2 vp2;
    TabLayout tabLayout1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        SharedPreferences preferencias = getSharedPreferences("agenda", Context.MODE_PRIVATE);
        for (int i = 0; i < dias.length; i++) {
            String acti=preferencias.getString(dias[i],"");
            actividades[i]=acti;
        }


        vp2 = findViewById(R.id.vp2);
        tabLayout1 = findViewById(R.id.tablayout1);

        vp2.setAdapter(new AdaptadorAgenda());

        // Aca configuramos los metodos para tablayout
        TabLayoutMediator tlm = new TabLayoutMediator(tabLayout1, vp2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                tab.setText(dias[position]);
            }
        });
        tlm.attach();
    }


    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences preferencias = getSharedPreferences("agenda", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor1 = preferencias.edit();
        for (int i = 0; i < dias.length; i++) {
            editor1.putString(dias[i], actividades[i]);
        }
        editor1.commit();


    }

    private class AdaptadorAgenda extends RecyclerView.Adapter<AdaptadorAgenda.AdaptadorAgendaHolder> {
        @NonNull
        @Override
        public AdaptadorAgendaHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorAgendaHolder(getLayoutInflater().inflate(R.layout.layoutdia, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorAgendaHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return dias.length;
        }

        class AdaptadorAgendaHolder extends RecyclerView.ViewHolder {
            EditText et1;

            public AdaptadorAgendaHolder(@NonNull View itemView) {
                super(itemView);
                et1 = itemView.findViewById(R.id.etActividades);

                // Usa un TextWatcher para guardar los cambios de texto
                et1.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        // No es necesario implementar
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        // Almacenar los datos cuando cambie el texto
                        actividades[getAdapterPosition()] = s.toString();
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        // No es necesario implementar
                    }
                });
            }

            public void imprimir(int position) {
                // Asegúrate de que el EditText muestra los datos correctos
                et1.setText(actividades[position]);
            }
        }
    }
}








