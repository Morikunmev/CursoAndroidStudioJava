package com.cursoandroid.n15activity2;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
public class MainActivity2 extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tv1 = findViewById(R.id.tv1);
        Bundle datos= getIntent().getExtras();
        int valor1 = datos.getInt("valor1");
        int valor2 = datos.getInt("valor2");
        String op = datos.getString("operacion");
        switch (op){
            case "sumar":
                int suma = valor1 + valor2;
                tv1.setText(valor1 + "+ "+ valor2+"="+suma);
                break;
            case "restar":
                int resta = valor1 - valor2;
                tv1.setText(valor1 + "- "+ valor2+"="+resta);
                break;
            case "multiplicar":
                int multiplicacion = valor1 * valor2;
                tv1.setText(valor1 + " * "+ valor2+"="+multiplicacion);
                break;
            case "dividir":
                int div = valor1/valor2;
                tv1.setText(valor1+"/"+valor2+"="+div);
                break;
        }
    }
    public void retornar(View v){
        finish();
    }
}