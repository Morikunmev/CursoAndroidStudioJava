package com.cursoandroid.n15activity2;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
public class MainActivity extends AppCompatActivity {
    EditText et1,et2;
    Spinner sp1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et1= findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        sp1=findViewById(R.id.spinner1);
        String[] operaciones={"sumar", "restar","multiplcar", "dividir"};
        ArrayAdapter <String> adaptado1 =new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,operaciones);
        sp1.setAdapter(adaptado1);
    }
    public void mostrarResultado(View view) {
        Intent intento1 = new Intent(this,MainActivity2.class);
        int valor1= Integer.parseInt(et1.getText().toString());
        int valor2= Integer.parseInt(et2.getText().toString());
        String operacion=sp1.getSelectedItem().toString();
        intento1.putExtra("valor1",valor1);
        intento1.putExtra("valor2",valor2);
        intento1.putExtra("operacion",operacion);
        startActivity(intento1);
    }
}