package com.cursoandroid.n22menuopcionesbarratitulo;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tv1=findViewById(R.id.tv1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menudeopciones, menu);
        Log.d("MainActivity", "onCreateOptionsMenu called");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int nro = item.getItemId();
        float valor;
        if (nro == R.id.agrandarfuente) {
            valor = tv1.getTextSize();
            valor = valor + 20;
            tv1.setTextSize(TypedValue.COMPLEX_UNIT_PX, valor);
            return true;
        } else if (nro == R.id.reducirfuente) {
            valor = tv1.getTextSize();
            valor = valor - 20;
            tv1.setTextSize(TypedValue.COMPLEX_UNIT_PX, valor);
            return true;
        } else if (nro == R.id.salir) {
            finish();
            return true;
        } else if (nro == R.id.rojo){
            tv1.setTextColor(Color.RED);
            return true;
        } else if (nro == R.id.verde){
            tv1.setTextColor(Color.GREEN);
            return true;
        } else if (nro== R.id.azul) {
            tv1.setTextColor(Color.BLUE);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
}