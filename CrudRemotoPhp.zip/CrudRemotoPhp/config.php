<?php
// Datos de la conexión a Railway
// Datos de la conexión a Clever Cloud
$servername = "bytsjoft0wwyw6ejxsln-mysql.services.clever-cloud.com"; // MySQL Host Name (Clever Cloud)
$username = "uajf9ondgoxova8c";                                       // MySQL User Name (Clever Cloud)
$password = "D4vgYi5zzfHyXN12tGTz";                                                       // MySQL Password (Clever Cloud) // Aquí debes colocar la contraseña correcta
$dbname = "bytsjoft0wwyw6ejxsln";                                   // MySQL DB Name (Clever Cloud)
$port = 3306;

// Crear la conexión a Railway
$conexion = mysqli_connect($servername, $username, $password, $dbname, $port);

// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}
?>
