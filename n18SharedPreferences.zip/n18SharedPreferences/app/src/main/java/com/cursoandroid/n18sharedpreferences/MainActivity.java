package com.cursoandroid.n18sharedpreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.graphics.ShaderKt;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText et1, et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
    }
    public void guardar(View v){
        SharedPreferences sp = getSharedPreferences("agenda", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String fecha= et1.getText().toString();
        String actividades= et2.getText().toString();
        editor.putString(fecha, actividades);
        editor.commit();
        et1.setText("");
        et2.setText("");
        Toast.makeText(this, "Las actividades fueron registradas", Toast.LENGTH_SHORT).show();
    }
    public void recuperar(View v){
        SharedPreferences sp = getSharedPreferences("agenda",Context.MODE_PRIVATE);
        String dato = sp.getString(et1.getText().toString(),"");
        if(dato.equals(""))
        {
            et2.setText("");
            Toast.makeText(this, "No hay actividades registradas para esa fecha", Toast.LENGTH_SHORT).show();
        }
        else
        {
            et2.setText(dato);
        }

    }
    }