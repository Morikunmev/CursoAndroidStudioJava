package com.cursoandroid.n20controlviewpager2;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

public class MainActivity extends AppCompatActivity {
    String [] paises ={"brazil", "chile", "colombia", "venezuela"};
    int []fotos = {R.drawable.brazil, R.drawable.chile, R.drawable.colombia, R.drawable.venezuela};
    ViewPager2 vp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        vp = findViewById(R.id.vp);
        vp.setAdapter(new AdaptadorPaises());
        vp.setOrientation(ViewPager2.ORIENTATION_VERTICAL);
    }

    private class AdaptadorPaises extends RecyclerView.Adapter<AdaptadorPaises.AdaptadorPaisHolder> {
        @NonNull
        @Override
        public AdaptadorPaisHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorPaisHolder(getLayoutInflater().inflate(R.layout.layoutpais,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorPaisHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return paises.length;
        }
        class AdaptadorPaisHolder extends RecyclerView.ViewHolder{
            ImageView iv1;
            TextView tv1;
            public AdaptadorPaisHolder(@NonNull View itemView){
                super(itemView);
                iv1=itemView.findViewById(R.id.ivpais);
                tv1= itemView.findViewById(R.id.tvpais);
            }

            public void imprimir(int position) {
                iv1.setImageResource(fotos[position]);
                tv1.setText(paises[position]);
            }
        }
    }}
