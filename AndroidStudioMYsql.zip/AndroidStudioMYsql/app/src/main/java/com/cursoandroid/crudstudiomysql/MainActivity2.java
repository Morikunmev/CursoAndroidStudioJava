package com.cursoandroid.crudstudiomysql;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {
    Button btnDelete, btnEdit, btnRegresar;
    EditText etName, etPassword, etEmail, etPhone, etId;
    String id;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        requestQueue = Volley.newRequestQueue(this);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            id = extras.getString("id");
        }

        // UI
        initUI();
        readUser();
    }

    private void initUI() {
        // EditTexts
        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etId = findViewById(R.id.etId);

        // Buttons
        btnDelete = findViewById(R.id.btnDelete);
        btnEdit = findViewById(R.id.btnEdit);
        btnRegresar = findViewById(R.id.atras); // Inicializa el botón "Regresar"

        // Set OnClickListener for buttons
        btnDelete.setOnClickListener(this);
        btnEdit.setOnClickListener(this);
        btnRegresar.setOnClickListener(this); // Agrega el listener


        Log.d("MainActivity2", "Activity creada"); // Logcat para depuración
    }

    private void readUser() {
        String url = String.format("http://192.168.1.85:8012/android/fetch.php?id=%s", id);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("MainActivity2", "Respuesta recibida"); // Logcat para depuración
                        try {
                            String name = response.getString("name");
                            String email = response.getString("email");
                            String password = response.getString("password");
                            String phone = response.getString("phone");
                            String id = response.getString("id");

                            etName.setText(name);
                            etEmail.setText(email);
                            etPassword.setText(password);
                            etPhone.setText(phone);
                            etId.setText(id);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(MainActivity2.this, "No se pudo encontrar el id en la base de datos", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Verifica si hay una respuesta de red y extrae el código de estado
                        if (error.networkResponse != null) {
                            int statusCode = error.networkResponse.statusCode;
                            Log.e("MainActivity2", "Error de red. Código de estado: " + statusCode);
                        } else {
                            Log.e("MainActivity2", "Error en la conexión: " + error.getMessage()); // Error genérico
                        }
                        Toast.makeText(MainActivity2.this, "Error en la conexión", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        requestQueue.add(jsonObjectRequest);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnEdit) {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();

            updateUser(name, email, password, phone);

        } else if (id == R.id.btnDelete) {
            String idUser = etId.getText().toString().trim();
            removeUser(idUser);

        }else if(id ==R.id.atras){
            finish();
        }
    }

    private void updateUser(final String name, final String email, final String password, final String phone) {
        String URL = "http://192.168.1.85:8012/android/edit.php";
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(MainActivity2.this, "Usuario actualizado con exito", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                params.put("name", name);
                params.put("email", email);
                params.put("password", password);
                params.put("phone", phone);
                return params;
            }
        }; // Corregido aquí
        requestQueue.add(stringRequest); // Asegúrate de añadir la solicitud a la cola
    }


    private void removeUser(final String idUser) {
        String URL = "http://192.168.1.85:8012/android/delete.php";
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(MainActivity2.this, "Usuario eliminado con exito", Toast.LENGTH_SHORT).show();
                finish();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity2.this, "Error al eliminar el usuario", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id", idUser);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
