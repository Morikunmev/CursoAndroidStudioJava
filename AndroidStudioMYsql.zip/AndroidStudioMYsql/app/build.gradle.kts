plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android) // Plugin de Kotlin agregado
}

android {
    namespace = "com.cursoandroid.crudstudiomysql"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cursoandroid.crudstudiomysql"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation(libs.kotlin) // Dependencia de Kotlin
    implementation(libs.volley) // Dependencia de Volley
    implementation(libs.appcompat) // Dependencia de AppCompat
    implementation(libs.material) // Dependencia de Material Design
    implementation(libs.activity) // Dependencia de Activity
    implementation(libs.constraintlayout) // Dependencia de ConstraintLayout
    testImplementation(libs.junit) // Test JUnit
    androidTestImplementation(libs.ext.junit) // Test Ext JUnit
}
