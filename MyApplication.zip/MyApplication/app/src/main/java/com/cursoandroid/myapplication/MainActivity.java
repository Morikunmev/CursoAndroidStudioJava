package com.cursoandroid.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView tv1;
    String pais;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tv1 = findViewById(R.id.tv1);
        int nro=(int) (Math.random()*5);
        switch (nro){
            case 0: pais="Argentina"; break;
            case 1: pais="Brasil"; break;
            case 2: pais="Chile"; break;
            case 3: pais="Colombia"; break;
            case 4: pais="Peru"; break;
        }
        tv1.setText("Cual es la bandera de "+ pais);

    }

    public void presion(View v){
        ImageButton b = (ImageButton)v;
        if(b.getTag().toString().equals(pais))
            Toast.makeText(this,"Muy bien",Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this,"Es incorrecto señalaste la bandera de "+b.getTag().toString(),Toast.LENGTH_SHORT).show();

    }
}